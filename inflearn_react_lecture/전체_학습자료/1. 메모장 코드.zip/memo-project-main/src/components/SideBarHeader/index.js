import './index.css';

function SideBarHeader() {
  return <div className="SideBarHeader">메모장</div>;
}

export default SideBarHeader;
